#include "Animal.h"
using namespace std;
Animal::Animal(int a) : age(a) {}

Animal& Animal::operator++() {
    ++age;
    return *this;
}

Animal Animal::operator++(int) {
    Animal temp = *this;
    ++(*this);
    return temp;
}

Animal& Animal::operator--() {
    --age;
    return *this;
}

Animal Animal::operator--(int) {
    Animal temp = *this;
    --(*this);
    return temp;
}

bool Animal::operator>(const Animal& other) const {
    return age > other.age;
}

bool Animal::operator<(const Animal& other) const {
    return age < other.age;
}

ostream& operator<<(ostream& out, const Animal& a) {
    out << "Age: " << a.age;
    return out;
}