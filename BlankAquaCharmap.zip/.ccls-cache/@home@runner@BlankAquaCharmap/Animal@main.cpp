#include <iostream>
using namespace std;
#include "Animal.h"

int main() {
  Animal dog(5);
  Animal cat(3);

  cout << "Initial Ages:" << endl;
  cout << "Dog: " << dog << endl;
  cout << "Cat: " << cat << endl;

  ++dog;
  cat--;

  cout << "\nAfter Incrementing and Decrementing:" << endl;
  cout << "Dog: " << dog << endl;
  cout << "Cat: " << cat << endl;

  cout << "\nComparison:" << endl;
  if (dog > cat) {
    cout << "Dog is older than Cat." << endl;
  } else if (dog < cat) {
    cout << "Cat is older than Dog." << endl;
  } else {
    cout << "Dog and Cat have the same age." << endl;
  }

  return 0;
}