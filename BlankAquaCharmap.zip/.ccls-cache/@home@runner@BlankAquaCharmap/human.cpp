#include "human.h"
using namespace std;
#include <iostream>
Human::Human(int h) : height(h) {}

Human& Human::operator++() {
height++;
return *this;
}

Human& Human::operator--() {
height--;
return *this;
}

bool Human::operator>(const Human& other) {
return height > other.height;
}

bool Human::operator<(const Human& other) {
return height < other.height;
}

ostream& operator<<(ostream& os, const Human& human) {
os << "Human height: " << human.height << " cm";
return os;
}