#ifndef AUTO_H
#define AUTO_H
#include <iostream>
using namespace std;

class Auto {
private:
    int speed;

public:
    Auto(int s);

    Auto& operator++();   
    Auto operator++(int); 
    Auto& operator--();   
    Auto operator--(int); 

    bool operator>(const Auto& other) const;
    bool operator<(const Auto& other) const;

    friend ostream& operator<<(ostream& out, const Auto& a);
};

#endif 