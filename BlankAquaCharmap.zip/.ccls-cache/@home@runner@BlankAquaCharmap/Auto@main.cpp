#include <iostream>
#include "Auto.h"
using namespace std;

int main() {
    Auto car1(50);
    Auto car2(60);

    cout << "Initial Speeds:" << endl;
    cout << "Car 1: " << car1 << endl;
    cout << "Car 2: " << car2 << endl;

    ++car1;
    car2--;

    cout << "\nAfter Incrementing and Decrementing:" << endl;
    cout << "Car 1: " << car1 << endl;
    cout << "Car 2: " << car2 << endl;

    cout << "\nComparison:" << endl;
    if (car1 > car2) {
        cout << "Car 1 is faster than Car 2." << endl;
    } else if (car1 < car2) {
        cout << "Car 2 is faster than Car 1." << endl;
    } else {
        cout << "Car 1 and Car 2 have the same speed." << endl;
    }

    return 0;
}