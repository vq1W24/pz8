#include <iostream>
using namespace std;
#include "human.h"

int main() {
  Human person1(170);
  Human person2(175);

  cout << person1 << endl;
  cout << person2 << endl;

  if (person1 < person2) {
    cout << "Person 1 is shorter than Person 2" << endl;
  } else {
    cout << "Person 1 is taller than Person 2" << endl;
  }

  ++person1;
  cout << person1 << endl;

  return 0;
}