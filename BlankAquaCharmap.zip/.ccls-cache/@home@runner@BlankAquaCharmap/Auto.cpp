#include "Auto.h"
using namespace std;

Auto::Auto(int s) : speed(s) {}

Auto& Auto::operator++() {
    ++speed;
    return *this;
}

Auto Auto::operator++(int) {
    Auto temp = *this;
    ++(*this);
    return temp;
}

Auto& Auto::operator--() {
    --speed;
    return *this;
}

Auto Auto::operator--(int) {
    Auto temp = *this;
    --(*this);
    return temp;
}

bool Auto::operator>(const Auto& other) const {
    return speed > other.speed;
}

bool Auto::operator<(const Auto& other) const {
    return speed < other.speed;
}

ostream& operator<<(ostream& out, const Auto& a) {
    out << "Speed: " << a.speed;
    return out;
}