#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>
using namespace std;

class Animal {
private:
    int age;

public:
    Animal(int a);

    Animal& operator++();   
    Animal operator++(int); 
    Animal& operator--();   
    Animal operator--(int); 

    bool operator>(const Animal& other) const;
    bool operator<(const Animal& other) const;

    friend ostream& operator<<(ostream& out, const Animal& a);
};

#endif 