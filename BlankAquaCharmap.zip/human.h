#include <iostream>
using namespace std;
#ifndef HUMAN_H
#define HUMAN_H

class Human {
private:
  int height;

public:
  Human(int h);

  Human &operator++();
  Human &operator--();

  bool operator>(const Human &other);
  bool operator<(const Human &other);

  friend ostream &operator<<(ostream &os, const Human &human);
};

#endif